#! /bin/bash
echo "Instalando calculadora... Por favor espere."

cd Proyecto_Calculadora
mkdir build
cd build 
cmake ..
make
./calculadora
