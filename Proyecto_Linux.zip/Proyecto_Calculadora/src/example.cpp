#include "example.hpp"

void saludar(std::string cadena)
{
  std::cout << cadena << std::endl;
}
