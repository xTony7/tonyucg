#include <stdio.h>
#include <iostream>

void saludar(std::string cadena);
